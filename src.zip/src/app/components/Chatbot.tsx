"use client";

import { useEffect, useRef, useState } from "react";
import { MessageCircle, Send, X } from "lucide-react";
import {
  sendBotMessage,
  extractLeadBlock,
  captureLead,
  saveConversationForReview,
} from "@/app/lib/chatAdapter";

type Message = { role: "user" | "assistant"; content: string };

const SYSTEM_PROMPT = `Eres "LEX", un Analista Legal Virtual de DeudaCero en Chile. Tu tono es siempre profesional, empático y tranquilizador. Tu objetivo es realizar un pre-diagnóstico y capturar la información del cliente.

**Reglas de Conversación:**
1.  **Preséntate** como LEX, tu analista legal virtual.
2.  **Usa mensajes cortos y claros.** Nunca escribas párrafos largos. Haz preguntas una a la vez para no abrumar al usuario.
3.  **Pide la información en etapas:** Primero nombre y contacto (email o teléfono). Luego, la situación de la deuda (motivo, acreedor, monto aproximado).
4.  **Manejo de Información Incompleta (MUY IMPORTANTE):** Si el usuario no tiene todos los datos, ¡NO es un problema! Tranquilízalo. Dile: "No te preocupes, con la información que me diste es suficiente para que un experto revise tu caso. Agendemos una evaluación gratuita para analizarlo en detalle." Tu objetivo es NUNCA perder un lead.
5.  **Generación del Lead:** Solo cuando tengas la información mínima (nombre + (email o teléfono) + motivo de la deuda), añade al FINAL de tu respuesta el bloque <LEAD>. No lo expliques. Sigue la conversación de forma natural.
6.  **Simula pausas:** Usa frases como "Entendido, permíteme revisar...", "Perfecto, un momento por favor..." antes de dar una respuesta.

**Formato del bloque LEAD (solo añadir al final de la respuesta cuando tengas los datos):**
<LEAD>{"name":"...", "email":"...", "phone":"...", "region":"...", "motivo":"...", "acreedor_principal":"...", "monto_total":0, "deudas_count":0, "dias_mora":0, "dicom":false}</LEAD>`;

const TypingIndicator = () => (
  <div className="flex justify-start">
    <div className="bg-zinc-800 text-zinc-100 max-w-[85%] rounded-2xl px-4 py-3 text-sm flex items-center space-x-2">
      <div className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-pulse [animation-delay:0.1s]"></div>
      <div className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-pulse [animation-delay:0.2s]"></div>
      <div className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-pulse [animation-delay:0.3s]"></div>
    </div>
  </div>
);

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [msgs, setMsgs] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hola, soy LEX, tu Analista Legal Virtual. ¿Cómo puedo ayudarte hoy con tus deudas?",
    },
  ]);
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, isTyping, open]);

  async function send() {
    const text = input.trim();
    if (!text || isTyping) return;

    setInput("");
    const userMessage: Message = { role: "user", content: text };
    const newHistory = [...msgs, userMessage];
    setMsgs(newHistory);
    setIsTyping(true);

    try {
      const { reply, conversationId } = await sendBotMessage(text, {
        systemPrompt: SYSTEM_PROMPT,
      });

      setIsTyping(false);
      const assistantMessage: Message = { role: "assistant", content: reply };
      setMsgs([...newHistory, assistantMessage]);

      const leadData = extractLeadBlock(reply);
      if (leadData) {
        await captureLead(leadData);
        console.log("Lead completo capturado:", leadData);
      } else if (newHistory.length > 5) {
        await saveConversationForReview(conversationId);
        console.log("Conversación larga guardada para revisión humana.");
      }
    } catch (e) {
      console.error(e);
      setIsTyping(false);
      const errorMessage: Message = { role: "assistant", content: "Lo siento, experimenté un problema técnico. Por favor, intenta de nuevo en un momento." };
      setMsgs((currentMsgs) => [...currentMsgs, errorMessage]);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen((v) => !v)}
        className="fixed bottom-5 right-5 z-50 rounded-full bg-emerald-600 p-3 text-white shadow-lg transition-transform hover:scale-110"
        aria-label="Abrir chat"
      >
        <MessageCircle size={28} />
      </button>

      {open && (
        <div className="fixed bottom-20 right-5 z-50 flex h-[calc(100vh-120px)] max-h-[600px] w-[360px] flex-col overflow-hidden rounded-2xl border border-zinc-800 bg-neutral-950 text-zinc-100 shadow-2xl">
          <header className="flex flex-shrink-0 items-center justify-between border-b border-zinc-800 px-4 py-3">
            <div className="text-sm font-semibold">Analista Legal Virtual — DeudaCero</div>
            <button onClick={() => setOpen(false)} className="text-zinc-400 hover:text-zinc-200">
              <X size={20} />
            </button>
          </header>

          <div className="flex-1 space-y-3 overflow-y-auto px-4 py-3">
            {msgs.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`${m.role === "user" ? "bg-emerald-600 text-white" : "bg-zinc-800 text-zinc-100"} max-w-[85%] whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm`}
                >
                  {m.content.replace(/<LEAD>[\s\S]*?<\/LEAD>/, '').trim()}
                </div>
              </div>
            ))}
            {isTyping && <TypingIndicator />}
            <div ref={bottomRef} />
          </div>

          <footer className="flex-shrink-0 border-t border-zinc-800 p-2">
            <div className="flex items-center gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && send()}
                placeholder="Escribe tu consulta…"
                className="flex-1 rounded-md border border-zinc-700 bg-neutral-900 px-3 py-2 text-sm text-zinc-100 placeholder:text-zinc-500 outline-none transition-colors focus:border-emerald-600"
              />
              <button
                onClick={send}
                disabled={isTyping || !input}
                className="rounded-md bg-emerald-600 p-2 text-sm text-white transition-colors disabled:opacity-50"
              >
                <Send size={20} />
              </button>
            </div>
          </footer>
        </div>
      )}
    </>
  );
}