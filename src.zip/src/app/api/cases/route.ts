import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/app/lib/supabaseAdmin';

// --- GET Request Handler ---
export async function GET(request: Request, context: { params: { id: string } }) {
  try {
    // El 'id' se extrae de forma segura gracias al tipado correcto del contexto.
    const { id } = context.params; 
    
    if (!id) {
      return NextResponse.json({ error: 'El ID del caso es requerido' }, { status: 400 });
    }

    const { data, error } = await supabaseAdmin
      .from('cases')
      .select(`
        id, short_code, estado, tipo, tribunal, rol, monto_demanda, created_at,
        lead:lead_id ( id, short_code, name, email, phone, motivo ),
        abogado:abogado_id ( id, name, email )
      `)
      .eq('id', id)
      .single();

    if (error) {
      // Si el error es 'PGRST116', significa que no se encontró el registro.
      if (error.code === 'PGRST116') {
        return NextResponse.json({ error: `No se encontró un caso con el ID: ${id}` }, { status: 404 });
      }
      throw error;
    }

    return NextResponse.json({ item: data });
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Ocurrió un error interno en el servidor.';
    console.error(`Error en GET /api/cases/[id]:`, e);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// --- PATCH Request Handler ---
export async function PATCH(request: Request, context: { params: { id: string } }) {
  try {
    const { id } = context.params;
    
    if (!id) {
      return NextResponse.json({ error: 'El ID del caso es requerido' }, { status: 400 });
    }

    const body = await request.json() as {
      estado?: string;
      tipo?: string;
      tribunal?: string | null;
      rol?: string | null;
      monto_demanda?: number | null;
      abogado_id?: string | null;
    };

    const { error } = await supabaseAdmin
      .from('cases')
      .update(body)
      .eq('id', id);

    if (error) {
      throw error;
    }

    return NextResponse.json({ ok: true, message: 'Caso actualizado correctamente.' });
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Ocurrió un error interno en el servidor.';
    console.error(`Error en PATCH /api/cases/[id]:`, e);
    return NextResponse.json({ ok: false, error: msg }, { status: 500 });
  }
}