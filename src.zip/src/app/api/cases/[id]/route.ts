// Archivo: src/app/api/cases/[id]/route.ts
// Reemplaza todo el contenido con este código

import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/app/lib/supabaseAdmin';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    
    if (!id) {
      return NextResponse.json({ error: 'El ID del caso es requerido' }, { status: 400 });
    }

    // --- CORRECCIÓN CLAVE AQUÍ ---
    // Esta consulta ahora selecciona correctamente los datos del caso y del lead asociado.
    const { data, error } = await supabaseAdmin
      .from('cases')
      .select(`
        *,
        lead:leads (*),
        abogado:users (*)
      `)
      .eq('id', id)
      .single();

    if (error) {
      // Si el error es 'PGRST116', significa que no se encontró el registro.
      if (error.code === 'PGRST116') {
        return NextResponse.json({ error: `No se encontró un caso con el ID: ${id}` }, { status: 404 });
      }
      // Si es otro error (como el de la columna que ya arreglamos), lo lanzará.
      throw error;
    }

    return NextResponse.json(data);
  } catch (e: any) {
    console.error(`Error en GET /api/cases/[id]:`, e);
    const msg = e.message ?? 'Ocurrió un error interno en el servidor.';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// (La función PATCH puede quedar como estaba, pero aquí la incluyo por si acaso)
export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    
    if (!id) {
      return NextResponse.json({ error: 'id requerido' }, { status: 400 });
    }

    const body = await request.json();

    const { error } = await supabaseAdmin
      .from('cases')
      .update(body)
      .eq('id', id);

    if (error) {
      throw error;
    }

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    const msg = e.message ?? 'Error interno';
    return NextResponse.json({ ok: false, error: msg }, { status: 500 });
  }
}