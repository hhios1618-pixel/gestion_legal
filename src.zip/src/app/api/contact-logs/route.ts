import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/app/lib/supabaseAdmin';

// GET: listar logs por lead_id o case_id
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const lead_id = url.searchParams.get('lead_id');
    const case_id = url.searchParams.get('case_id');

    const query = supabaseAdmin.from('contact_logs')
      .select('id, lead_id, case_id, by_user, channel, outcome, notes, contacted_at')
      .order('contacted_at', { ascending: false })
      .limit(200);

    if (lead_id) query.eq('lead_id', lead_id);
    if (case_id) query.eq('case_id', case_id);

    const { data, error } = await query;
    if (error) throw error;

    return NextResponse.json({ ok: true, items: data ?? [] });
  } catch (e:any) {
    return NextResponse.json({ ok:false, error: e.message }, { status: 500 });
  }
}