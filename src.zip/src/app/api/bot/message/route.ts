import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/app/lib/supabaseAdmin';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });

export async function POST(req: NextRequest) {
  try {
    let { conversationId, userEmail, message, systemPrompt } = await req.json();

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'message requerido' }, { status: 400 });
    }

    const userMessage = { role: 'user', content: message };
    const { data: returnedConvId, error: convErr } = await supabaseAdmin.rpc(
      'bot_upsert_conversation',
      {
        p_conversation_id: conversationId ?? null,
        p_user_email: userEmail ?? null,
        p_message: userMessage,
      }
    );
    if (convErr) throw convErr;

    conversationId = returnedConvId;

    const { data: conversationData, error: getErr } = await supabaseAdmin
      .from('conversations')
      .select('messages')
      .eq('id', conversationId)
      .single();
      
    if (getErr) throw getErr;

    const history = conversationData?.messages || [];

    const messagesForAPI = [
      ...(systemPrompt ? [{ role: 'system' as const, content: systemPrompt }] : []),
      ...history.slice(-30),
    ];

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: messagesForAPI,
      temperature: 0.2,
    });

    const assistantText = completion.choices[0]?.message?.content ?? 'No pude procesar tu solicitud.';

    const assistantMessage = { role: 'assistant', content: assistantText };
    const { error: appendErr } = await supabaseAdmin.rpc('bot_upsert_conversation', {
      p_conversation_id: conversationId,
      p_user_email: userEmail ?? null,
      p_message: assistantMessage,
    });
    if (appendErr) throw appendErr;

    return NextResponse.json({ conversationId: conversationId, reply: assistantText }, { status: 200 });

  } catch (e: any) {
    console.error('[bot/message] error', e);
    return NextResponse.json({ error: e.message ?? 'Error interno del servidor' }, { status: 500 });
  }
}