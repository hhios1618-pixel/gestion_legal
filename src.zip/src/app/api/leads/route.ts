import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/app/lib/supabaseAdmin';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      conversationId,
      name, email, phone, region,
      motivo, acreedor_principal,
      monto_total, deudas_count, dias_mora, dicom
    } = body;

    const { data, error } = await supabaseAdmin.rpc('bot_capture_lead', {
      p_conversation_id: conversationId ?? null,
      p_name: name ?? null,
      p_email: email ?? null,
      p_phone: phone ?? null,
      p_region: region ?? null,
      p_motivo: motivo ?? null,
      p_acreedor_principal: acreedor_principal ?? null,
      p_monto_total: monto_total ?? null,
      p_deudas_count: deudas_count ?? null,
      p_dias_mora: dias_mora ?? null,
      p_dicom: dicom ?? null
    });

    if (error) throw error;
    return NextResponse.json({ leadId: data }, { status: 200 });
  } catch (e: any) {
    console.error('[leads POST] error', e);
    return NextResponse.json({ error: e.message ?? 'Error interno' }, { status: 500 });
  }
}

export async function GET() {
  try {
    const { data, error } = await supabaseAdmin
      .from('vw_leads_recent')
      .select('*');
    if (error) throw error;
    return NextResponse.json({ items: data ?? [] }, { status: 200 });
  } catch (e: any) {
    console.error('[leads GET] error', e);
    return NextResponse.json({ error: e.message ?? 'Error interno' }, { status: 500 });
  }
}