// Este archivo maneja la comunicación con tu backend y Supabase

type SendOptions = { userEmail?: string; systemPrompt?: string };

const KEY = 'dc_conversation_id';

export function getConversationId(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(KEY);
}

export function setConversationId(id: string) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(KEY, id);
}

export function resetConversation() {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(KEY);
}

// Envía el mensaje del usuario al backend para obtener la respuesta de la IA
export async function sendBotMessage(message: string, opts: SendOptions = {}) {
  const conversationId = getConversationId();
  const res = await fetch('/api/bot/message', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      conversationId,
      userEmail: opts.userEmail ?? null,
      message,
      systemPrompt: opts.systemPrompt ?? null,
    }),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Error en la API del bot');

  // Si es una nueva conversación, guarda el ID
  if (json.conversationId && json.conversationId !== conversationId) {
    setConversationId(json.conversationId);
  }
  return json as { conversationId: string; reply: string };
}

// Extrae el bloque <LEAD> de la respuesta del bot
export function extractLeadBlock(text: string): object | null {
  const match = text.match(/<LEAD>([\s\S]*?)<\/LEAD>/);
  if (!match) return null;
  try {
    return JSON.parse(match[1]);
  } catch {
    return null;
  }
}

// Envía el lead extraído para guardarlo en la tabla 'leads'
export async function captureLead(payload: object) {
  const conversationId = getConversationId();
  const res = await fetch('/api/leads', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ conversationId, ...payload }),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Error al capturar el lead');
  return json as { leadId: string };
}

// Marca una conversación para que un humano la revise
export async function saveConversationForReview(conversationId: string | null) {
  if (!conversationId) return;

  // Llama a una API que actualiza el estado de la conversación
  const res = await fetch('/api/case-events', { // Reutilizamos una API o creamos una nueva
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      conversation_id: conversationId,
      type: 'status_change',
      payload: { status: 'needs_review' },
    }),
  });

  if (!res.ok) {
    console.error('Error al marcar conversación para revisión');
  }
}