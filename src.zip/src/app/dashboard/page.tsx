import { FolderKanban, Users, MessageSquareText } from 'lucide-react';

// Esta será la página que se muestre en la ruta /dashboard
export default function DashboardHomePage() {
  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold text-zinc-100">Resumen General</h1>
      
      {/* Grid de Tarjetas de Estadísticas (KPIs) */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        <StatCard
          title="Total de Casos"
          value="1,254"
          description="+20% desde el mes pasado"
          icon={<FolderKanban className="text-emerald-500" />}
        />
        <StatCard
          title="Leads Activos"
          value="320"
          description="+15 nuevos hoy"
          icon={<Users className="text-sky-500" />}
        />
        <StatCard
          title="Conversaciones"
          value="89"
          description="Necesitan revisión"
          icon={<MessageSquareText className="text-amber-500" />}
        />
      </div>

      {/* Aquí podrías agregar más componentes, como gráficos o tablas de datos recientes */}
      <div className="mt-8">
        <div className="rounded-xl border border-zinc-800 bg-neutral-950 p-4">
          <h3 className="mb-4 font-semibold">Actividad Reciente</h3>
          <p className="text-sm text-zinc-400">
            Aquí iría un componente con la lista de los últimos leads o casos actualizados.
          </p>
        </div>
      </div>
    </div>
  );
}

// Componente para las tarjetas de estadísticas
function StatCard({ title, value, description, icon }: { title: string; value: string; description: string; icon: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-zinc-800 bg-neutral-950 p-5">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-zinc-400">{title}</p>
        {icon}
      </div>
      <div className="mt-2">
        <p className="text-3xl font-bold">{value}</p>
        <p className="text-xs text-zinc-500">{description}</p>
      </div>
    </div>
  );
}