"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, FolderKanban, Users, Settings } from 'lucide-react';

// Este componente Layout envolverá todas las páginas dentro de /dashboard
export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex h-screen w-full bg-neutral-900 text-zinc-100">
      {/* Barra de Navegación Lateral (Sidebar) */}
      <aside className="w-64 flex-shrink-0 border-r border-zinc-800 bg-neutral-950 p-4">
        <div className="flex h-full flex-col">
          <h1 className="mb-8 text-xl font-bold text-emerald-500">
            DeudaCero
          </h1>
          <nav className="flex flex-col space-y-2">
            <DashboardLink href="/dashboard" icon={<LayoutDashboard size={20} />}>
              Resumen
            </DashboardLink>
            <DashboardLink href="/dashboard/cases" icon={<FolderKanban size={20} />}>
              Casos
            </DashboardLink>
            <DashboardLink href="/dashboard/leads" icon={<Users size={20} />}>
              Leads
            </DashboardLink>
            <DashboardLink href="/dashboard/admin" icon={<Settings size={20} />}>
              Admin
            </DashboardLink>
          </nav>
        </div>
      </aside>

      {/* Contenido Principal */}
      <main className="flex-1 overflow-y-auto">
        <header className="sticky top-0 border-b border-zinc-800 bg-neutral-900/50 p-4 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Panel de Control</h2>
            <div className="h-8 w-8 rounded-full bg-emerald-600"></div>
          </div>
        </header>
        <div className="p-6">
          {children} {/* Aquí se renderizará el contenido de cada página */}
        </div>
      </main>
    </div>
  );
}

// Componente auxiliar para los enlaces de navegación con estado activo
function DashboardLink({ href, icon, children }: { href: string; icon: React.ReactNode; children: React.ReactNode }) {
  const pathname = usePathname();
  const isActive = pathname === href;

  return (
    <Link
      href={href}
      className={`flex items-center gap-3 rounded-md px-3 py-2 text-zinc-400 transition-colors hover:bg-zinc-800 hover:text-zinc-100 ${
        isActive ? 'bg-zinc-800 text-zinc-100' : ''
      }`}
    >
      {icon}
      <span className="text-sm font-medium">{children}</span>
    </Link>
  );
}