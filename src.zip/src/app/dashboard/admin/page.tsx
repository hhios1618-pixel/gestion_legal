import { Settings } from 'lucide-react';

export default function AdminPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-zinc-100 flex items-center gap-3 mb-6">
        <Settings size={28} />
        Panel de Administración
      </h1>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="rounded-xl border border-zinc-800 bg-neutral-950 p-5">
          <h3 className="font-semibold text-lg mb-2">Configuración del Chatbot</h3>
          <p className="text-sm text-zinc-400 mb-4">
            Aquí podrías agregar opciones para cambiar el System Prompt del bot,
            ver conversaciones marcadas para revisión, etc.
          </p>
          <button className="bg-emerald-600 text-white px-4 py-2 rounded-md text-sm font-semibold hover:bg-emerald-700 transition-colors">
            Ajustar Prompt
          </button>
        </div>

        <div className="rounded-xl border border-zinc-800 bg-neutral-950 p-5">
          <h3 className="font-semibold text-lg mb-2">Gestión de Usuarios</h3>
          <p className="text-sm text-zinc-400 mb-4">
            Espacio para una futura tabla de gestión de usuarios del sistema,
            roles y permisos.
          </p>
           <button className="bg-zinc-700 text-white px-4 py-2 rounded-md text-sm font-semibold hover:bg-zinc-600 transition-colors">
            Ver Usuarios
          </button>
        </div>
      </div>
    </div>
  );
}