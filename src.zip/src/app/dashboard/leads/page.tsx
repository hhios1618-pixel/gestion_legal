import { createServerComponentClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';
import { Users } from 'lucide-react';
import Link from 'next/link';

// ARREGLO 1: Fuerza el renderizado dinámico para solucionar el error de cookies.
export const dynamic = 'force-dynamic';

// ARREGLO 2: Define manualmente la estructura de un Lead.
interface Lead {
  id: string;
  created_at: string;
  short_code: string | null;
  name: string | null;
  email: string | null;
  status: string | null;
  channel: string | null;
}

export default async function LeadsPage() {
  const supabase = createServerComponentClient({ cookies });

  const { data, error } = await supabase
    .from('leads')
    .select('*')
    .order('created_at', { ascending: false });

  // Forzamos el tipo aquí para que TypeScript entienda los datos.
  const leads = data as Lead[] | null;

  if (error) {
    return <p className="text-red-500">Error al cargar los leads: {error.message}</p>;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-zinc-100 flex items-center gap-3">
          <Users size={28} />
          Registro de Leads
        </h1>
      </div>

      <div className="rounded-xl border border-zinc-800 bg-neutral-950">
        <table className="w-full text-sm text-left text-zinc-400">
          <thead className="text-xs text-zinc-400 uppercase bg-neutral-900">
            <tr>
              <th scope="col" className="px-6 py-3">Código</th>
              <th scope="col" className="px-6 py-3">Nombre</th>
              <th scope="col" className="px-6 py-3">Email</th>
              <th scope="col" className="px-6 py-3">Estado</th>
              <th scope="col" className="px-6 py-3">Canal</th>
              <th scope="col" className="px-6 py-3">Acción</th>
            </tr>
          </thead>
          <tbody>
            {leads && leads.map((lead) => (
              <tr key={lead.id} className="border-b border-zinc-800 hover:bg-neutral-800/50">
                <th scope="row" className="px-6 py-4 font-medium text-zinc-100 whitespace-nowrap">{lead.short_code}</th>
                <td className="px-6 py-4">{lead.name}</td>
                <td className="px-6 py-4">{lead.email}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    lead.status === 'Nuevo' ? 'bg-blue-900 text-blue-300' :
                    lead.status === 'Convertido' ? 'bg-purple-900 text-purple-300' :
                    'bg-zinc-700 text-zinc-300'
                  }`}>{lead.status}</span>
                </td>
                <td className="px-6 py-4">{lead.channel}</td>
                <td className="px-6 py-4">
                  <Link href={`/dashboard/leads/${lead.id}`} className="font-medium text-emerald-500 hover:underline">Gestionar</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}