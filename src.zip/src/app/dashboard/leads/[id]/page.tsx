import { createServerComponentClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { User, Mail, Phone, Tag, CheckSquare, FolderKanban } from 'lucide-react';

// ARREGLO 1: Fuerza el renderizado dinámico para solucionar el error de cookies.
export const dynamic = 'force-dynamic';

// ARREGLO 2: Define manualmente la estructura de un Lead.
interface Lead {
  id: string;
  created_at: string;
  short_code: string | null;
  name: string | null;
  email: string | null;
  phone: string | null;
  status: string | null;
  motivo: string | null;
}

export default async function LeadDetailPage({ params }: { params: { id: string } }) {
  const supabase = createServerComponentClient({ cookies });

  const { data, error } = await supabase
    .from('leads')
    .select('*')
    .eq('id', params.id)
    .single();

  // Forzamos el tipo aquí para que TypeScript entienda los datos.
  const lead = data as Lead | null;

  if (error || !lead) {
    return <p className="text-red-500">Lead no encontrado.</p>;
  }

  async function updateLeadStatus(formData: FormData) {
    "use server";
    const newStatus = formData.get('status') as string;
    const supabase = createServerComponentClient({ cookies });

    await supabase
      .from('leads')
      .update({ status: newStatus })
      .eq('id', params.id);
    
    revalidatePath(`/dashboard/leads/${params.id}`);
    revalidatePath('/dashboard/leads');
  }

  async function convertToCase() {
    "use server";
    if (!lead) return;
    const supabase = createServerComponentClient({ cookies });

    const { data: newCase, error: caseError } = await supabase
      .from('cases')
      .insert({
        lead_id: lead.id,
        estado: 'Activo',
        tipo: 'Prescripción',
      })
      .select('id')
      .single();

    if (caseError || !newCase) {
      console.error("Error creating case:", caseError);
      return;
    }

    await supabase
      .from('leads')
      .update({ status: 'Convertido' })
      .eq('id', params.id);
    
    revalidatePath('/dashboard/leads');
    revalidatePath('/dashboard/cases');
    
    redirect(`/dashboard/cases/${newCase.id}`);
  }

  const statuses = ['Nuevo', 'Contactado', 'En Seguimiento', 'No Califica', 'Convertido'];

  return (
    <div>
      <h1 className="text-2xl font-bold text-zinc-100 mb-2">Detalle del Lead: {lead.short_code}</h1>
      <p className="text-zinc-400 mb-6">Gestiona el estado y la información del cliente potencial.</p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 rounded-xl border border-zinc-800 bg-neutral-950 p-6 space-y-4">
          <InfoItem icon={<User size={18} />} label="Nombre" value={lead.name} />
          <InfoItem icon={<Mail size={18} />} label="Email" value={lead.email} />
          <InfoItem icon={<Phone size={18} />} label="Teléfono" value={lead.phone} />
          <InfoItem icon={<Tag size={18} />} label="Motivo Consulta" value={lead.motivo} />
        </div>

        <div className="rounded-xl border border-zinc-800 bg-neutral-950 p-6 space-y-6">
          <div>
            <h3 className="font-semibold mb-3 flex items-center gap-2"><CheckSquare size={18} /> Estado del Lead</h3>
            <form action={updateLeadStatus}>
              <select 
                name="status"
                defaultValue={lead.status ?? 'Nuevo'}
                className="w-full bg-zinc-800 border border-zinc-700 rounded-md p-2 mb-4 text-zinc-100"
              >
                {statuses.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <button 
                type="submit"
                className="w-full bg-emerald-600 text-white px-4 py-2 rounded-md text-sm font-semibold hover:bg-emerald-700"
              >
                Actualizar Estado
              </button>
            </form>
          </div>
          
          {lead.status !== 'Convertido' && (
            <div>
              <h3 className="font-semibold mb-3 flex items-center gap-2"><FolderKanban size={18} /> Acciones</h3>
              <form action={convertToCase}>
                <button 
                  type="submit"
                  className="w-full bg-sky-600 text-white px-4 py-2 rounded-md text-sm font-semibold hover:bg-sky-700"
                >
                  Convertir a Caso
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function InfoItem({ icon, label, value }: { icon: React.ReactNode, label: string, value: string | null }) {
  return (
    <div>
      <p className="text-xs text-zinc-500 flex items-center gap-2">{icon} {label}</p>
      <p className="text-zinc-100 font-medium">{value || 'No especificado'}</p>
    </div>
  );
}