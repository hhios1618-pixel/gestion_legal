'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';

const ESTADOS = ['nuevo','en_proceso','cerrado'] as const;
const TIPOS = ['extrajudicial','renegociacion_20720','judicial'] as const;

export default function CaseDetail() {
  const { id } = useParams<{id: string}>();
  const [item, setItem] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);

  const [estado, setEstado] = useState<string>('nuevo');
  const [tipo, setTipo] = useState<string>('extrajudicial');
  const [tribunal, setTribunal] = useState('');
  const [rol, setRol] = useState('');
  const [monto, setMonto] = useState<number | ''>('');
  const [abogadoId, setAbogadoId] = useState<string>('');
  const [evType, setEvType] = useState('audiencia');
  const [evDetail, setEvDetail] = useState('');

  // load
  useEffect(() => {
    (async () => {
      const [cr, ur, er] = await Promise.all([
        fetch(`/api/cases/${id}`, { cache: 'no-store' }),
        fetch('/api/users', { cache: 'no-store' }),
        fetch(`/api/case-events?case_id=${id}`, { cache: 'no-store' }),
      ]);
      const cjson = await cr.json();
      const ujson = await ur.json();
      const ejson = await er.json();

      setItem(cjson.item);
      setUsers(ujson.items || []);
      setEvents(ejson.items || []);

      if (cjson.item) {
        setEstado(cjson.item.estado ?? 'nuevo');
        setTipo(cjson.item.tipo ?? 'extrajudicial');
        setTribunal(cjson.item.tribunal ?? '');
        setRol(cjson.item.rol ?? '');
        setMonto(cjson.item.monto_demanda ?? '');
        setAbogadoId(cjson.item.abogado?.id ?? '');
      }
    })();
  }, [id]);

  async function saveCase() {
    setSaving(true);
    const body: any = {
      estado, tipo,
      tribunal: tribunal || null,
      rol: rol || null,
      monto_demanda: monto === '' ? null : Number(monto),
      abogado_id: abogadoId || null,
    };
    const r = await fetch(`/api/cases/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify(body),
    });
    setSaving(false);
    if (!r.ok) alert('Error guardando');
  }

  async function addEvent() {
    const body = { case_id: id, type: evType, detail: evDetail };
    const r = await fetch('/api/case-events', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)
    });
    if (r.ok) {
      setEvents([{ ...body, id: crypto.randomUUID(), event_date: new Date().toISOString() }, ...events]);
      setEvDetail('');
    } else {
      alert('Error creando evento');
    }
  }

  if (!item) return <div className="p-6">Cargando…</div>;

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-xl font-semibold">{item.short_code} — {item.lead?.name ?? '—'}</h1>

      <div className="grid sm:grid-cols-2 gap-4">
        {/* Editar datos del caso */}
        <div className="p-4 border border-white/10 rounded space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <label className="text-sm opacity-80">Estado
              <select value={estado} onChange={e=>setEstado(e.target.value)}
                className="w-full mt-1 rounded p-2 bg-black/30 border border-white/10">
                {ESTADOS.map(s=> <option key={s} value={s}>{s}</option>)}
              </select>
            </label>

            <label className="text-sm opacity-80">Tipo
              <select value={tipo} onChange={e=>setTipo(e.target.value)}
                className="w-full mt-1 rounded p-2 bg-black/30 border border-white/10">
                {TIPOS.map(t=> <option key={t} value={t}>{t}</option>)}
              </select>
            </label>

            <label className="text-sm opacity-80">Tribunal
              <input value={tribunal} onChange={e=>setTribunal(e.target.value)}
                className="w-full mt-1 rounded p-2 bg-black/30 border border-white/10"/>
            </label>

            <label className="text-sm opacity-80">Rol
              <input value={rol} onChange={e=>setRol(e.target.value)}
                className="w-full mt-1 rounded p-2 bg-black/30 border border-white/10"/>
            </label>

            <label className="text-sm opacity-80">Monto demanda (CLP)
              <input type="number" value={monto} onChange={e=>setMonto(e.target.value as any)}
                className="w-full mt-1 rounded p-2 bg-black/30 border border-white/10"/>
            </label>

            <label className="text-sm opacity-80">Abogado
              <select value={abogadoId} onChange={e=>setAbogadoId(e.target.value)}
                className="w-full mt-1 rounded p-2 bg-black/30 border border-white/10">
                <option value="">—</option>
                {users.map(u=> <option key={u.id} value={u.id}>{u.name}</option>)}
              </select>
            </label>
          </div>

          <button onClick={saveCase} disabled={saving}
            className="px-3 py-2 rounded bg-emerald-600 disabled:opacity-60">
            {saving ? 'Guardando…' : 'Guardar cambios'}
          </button>
        </div>

        {/* Registrar evento */}
        <div className="p-4 border border-white/10 rounded space-y-2">
          <div className="font-semibold">Registrar evento</div>
          <select value={evType} onChange={e=>setEvType(e.target.value)}
            className="w-full rounded p-2 bg-black/30 border border-white/10">
            {['ingreso','gestion_preparatoria','demanda','notificacion','requerimiento','embargo','remate','audiencia','acuerdo','cierre'].map(t=>
              <option key={t} value={t}>{t}</option>
            )}
          </select>
          <textarea value={evDetail} onChange={e=>setEvDetail(e.target.value)}
            placeholder="Detalle..."
            className="w-full h-24 rounded p-2 bg-black/30 border border-white/10"/>
          <button onClick={addEvent} className="px-3 py-2 rounded bg-emerald-600">Guardar evento</button>
        </div>
      </div>

      {/* Timeline */}
      <div>
        <div className="font-semibold mb-2">Eventos</div>
        <div className="space-y-2">
          {events.map((ev:any)=>(
            <div key={ev.id} className="p-3 border border-white/10 rounded">
              <div className="text-xs opacity-70">
                {ev.type} • {new Date(ev.event_date || ev.created_at).toLocaleString()}
              </div>
              <div>{ev.detail}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}