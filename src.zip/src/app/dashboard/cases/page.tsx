import { createServerComponentClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';
import { FolderKanban } from 'lucide-react';
import Link from 'next/link';

// ARREGLO 1: Fuerza el renderizado dinámico para solucionar el error de cookies.
export const dynamic = 'force-dynamic';

// ARREGLO 2: Define manualmente la estructura de un Caso.
interface Case {
    id: string;
    created_at: string;
    short_code: string | null;
    estado: string | null;
    tipo: string | null;
    tribunal: string | null;
}

export default async function CasesPage() {
  const supabase = createServerComponentClient({ cookies });

  const { data, error } = await supabase
    .from('cases')
    .select('*')
    .order('created_at', { ascending: false });

  // Forzamos el tipo aquí para que TypeScript entienda los datos.
  const cases = data as Case[] | null;

  if (error) {
    return <p className="text-red-500">Error al cargar los casos: {error.message}</p>;
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-zinc-100 flex items-center gap-3 mb-6">
        <FolderKanban size={28} />
        Gestión de Casos
      </h1>
      
      <div className="rounded-xl border border-zinc-800 bg-neutral-950">
        <table className="w-full text-sm text-left text-zinc-400">
          <thead className="text-xs text-zinc-400 uppercase bg-neutral-900">
            <tr>
              <th scope="col" className="px-6 py-3">Código</th>
              <th scope="col" className="px-6 py-3">Estado</th>
              <th scope="col" className="px-6 py-3">Tipo</th>
              <th scope="col" className="px-6 py-3">Tribunal</th>
              <th scope="col" className="px-6 py-3">Acción</th>
            </tr>
          </thead>
          <tbody>
            {cases && cases.map((c) => (
              <tr key={c.id} className="border-b border-zinc-800 hover:bg-neutral-800/50">
                <th scope="row" className="px-6 py-4 font-medium text-zinc-100 whitespace-nowrap">{c.short_code}</th>
                <td className="px-6 py-4">
                   <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    c.estado === 'Activo' ? 'bg-green-900 text-green-300' :
                    'bg-zinc-700 text-zinc-300'
                  }`}>{c.estado}</span>
                </td>
                <td className="px-6 py-4">{c.tipo}</td>
                <td className="px-6 py-4">{c.tribunal}</td>
                <td className="px-6 py-4">
                  <Link href={`/dashboard/cases/${c.id}`} className="font-medium text-emerald-500 hover:underline">Ver</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}